import pandas as pd
import warnings

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

def load_fleet_data_v3_hybrid(file_path): 
    """
    MASTER STRATEGY V13: CORRECT MULTI-YEAR STRUCTURE
    Based on user confirmation:
    - 2026: Rows 4-15 (monthly, 12 rows)
    - 2027: Rows 16-27 (monthly, 12 rows)
    - 2028: Rows 28-31 (quarterly, 4 rows)
    - 2029: Row 32+ (quarterly)
    
    Year headers are 1 row ABOVE data blocks (rows 3, 15, 27, 31).
    """
    print(f"--- LOADING FLEET V13 (CORRECT STRUCTURE) FROM: {file_path} ---")
    data_rows = []
    
    try:
        # --- PART A: PHASE MAP FROM PALA-FASE ---
        df_pf = pd.read_excel(file_path, sheet_name="Pala-Fase", header=None)
        
        time_map_pf = {} 
        current_year = 2026
        months_dict = {
            'ENE':1,'FEB':2,'MAR':3,'ABR':4,'MAY':5,'JUN':6,'JUL':7,'AGO':8,'SEP':9,'OCT':10,'NOV':11,'DIC':12,
            'ENERO':1,'FEBRERO':2,'MARZO':3,'ABRIL':4,'MAYO':5,'JUNIO':6,'JULIO':7,'AGOSTO':8,'SEPTIEMBRE':9,'OCTUBRE':10,'NOVIEMBRE':11,'DICIEMBRE':12
        }
        
        for c in range(2, df_pf.shape[1]):
            val_y = df_pf.iloc[0, c]
            if pd.notna(val_y): 
                try:
                    current_year = int(val_y)
                except:
                    pass
            
            raw_m = str(df_pf.iloc[1, c]).strip().upper()
            val_m = raw_m[:3] # fallback for months
            
            # Detect implicit Year in label (e.g. "_2028")
            if "_" in raw_m and "20" in raw_m:
                try:
                    parts = raw_m.split('_')
                    if len(parts) > 1 and parts[-1].isdigit():
                        current_year = int(parts[-1])
                except: pass

            if val_m in months_dict:
                time_map_pf[c] = (current_year, months_dict[val_m])
            elif "TRIMESTRE" in raw_m or "TRIM" in raw_m:
                 # Quarterly Column
                 q_num = 1
                 if "1" in raw_m or "1ER" in raw_m: q_num = 1
                 elif "2" in raw_m or "2DO" in raw_m: q_num = 2
                 elif "3" in raw_m or "3ER" in raw_m: q_num = 3
                 elif "4" in raw_m or "4TO" in raw_m: q_num = 4
                 
                 # Map to end-of-quarter month (3, 6, 9, 12)
                 time_map_pf[c] = (current_year, q_num * 3)

        # Apply FFILL to Col 0 and 1 for merged cells
        df_pf[0] = df_pf[0].fillna(method='ffill')
        df_pf[0] = df_pf[0].fillna(method='ffill')
        df_pf[1] = df_pf[1].fillna(method='ffill')

        # Build Phase Proportions Map
        # keyed by (month, equipment) -> List of {"phase": phase, "ton": value}
        phase_lookup = {}
        
        for i in range(2, len(df_pf)):
            mega_grupo = str(df_pf.iloc[i, 0]).strip().upper()
            equipo_label = str(df_pf.iloc[i, 1]).strip().upper()
            fase_label = str(df_pf.iloc[i, 2]).strip().upper()
            
            equip = None
            if "BULL" in equipo_label or "BULL" in mega_grupo: equip = "Bulldozer"
            elif "P04" in equipo_label: equip = "Pala 04"
            elif "P05" in equipo_label: equip = "Pala 05"
            elif "P06" in equipo_label: equip = "Pala 06"
            
            phase = None
            if "F05" in fase_label: phase = "Fase 5"
            elif "F04" in fase_label: phase = "Fase 4" 
            elif "F03" in fase_label: phase = "Fase 3"
            elif "REMANEJO" in mega_grupo: phase = "Remanejo"
            
            if equip and phase and "TOTAL" not in equipo_label:
                for c, (yr, mn) in time_map_pf.items():
                    val = pd.to_numeric(df_pf.iloc[i, c], errors='coerce')
                    if pd.notna(val) and val > 0:
                        # KEY CHANGE: Include Year in lookup key
                        key = (yr, mn, equip)
                        if key not in phase_lookup:
                            phase_lookup[key] = []
                        phase_lookup[key].append({"phase": phase, "ton": val})
                        
                        # Bulldozers are ONLY in this sheet
                        if equip == "Bulldozer":
                            data_rows.append({
                                'Year': yr, 'Month': mn, 
                                'Quarter': f"Q{(mn-1)//3 + 1}",
                                'Equipo': equip, 'Fase': phase,
                                'Ton': val, 'Source': 'Pala-Fase'
                            })

        # --- PART B: KPI-PALAS (MULTI-YEAR BLOCKS) ---
        df_kpi = pd.read_excel(file_path, sheet_name="KPI-Palas", header=None)
        
        # Identify equipment columns
        equip_cols = []
        for c in range(df_kpi.shape[1]):
            h0 = str(df_kpi.iloc[0, c]).strip().upper()
            h1 = str(df_kpi.iloc[1, c]).strip().upper()
            h2 = str(df_kpi.iloc[2, c]).strip().upper()
            
            combined = f"{h0} {h1}"
            eq = None
            if "P03" in combined: eq = "Pala 03"
            elif "P04" in combined: eq = "Pala 04"
            elif "P05" in combined: eq = "Pala 05"
            elif "P06" in combined: eq = "Pala 06"
            elif "CF" in combined or "CARGADOR" in combined: eq = "Cargador Frontal"
            
            if eq and ("TON" in h2 or "TON" in h1):
                # We store Ton col and Rend col (which is Ton col + 2 based on inspection)
                equip_cols.append({'col_ton': c, 'col_rend': c + 2, 'eq': eq})
        
        # Define year blocks based on ACTUAL diagnostic
        year_blocks = [
            (3, 2026, 3, 14, False),    # Monthly
            (15, 2027, 15, 26, False),  # Monthly
            (27, 2028, 27, 30, True),   # Quarterly
            (31, 2029, 31, 31, True)    # Quarterly
        ]
        
        for header_row, year, start_row, end_row, is_quarterly in year_blocks:
            if not is_quarterly:
                # MONTHLY PARSING (2026, 2027)
                row_month_map = {}
                for i in range(start_row, min(end_row + 1, len(df_kpi))):
                    val_m = str(df_kpi.iloc[i, 1]).strip().upper()
                    if val_m in months_dict:
                        row_month_map[i] = months_dict[val_m]
                
                for row_idx, month_num in row_month_map.items():
                    q = f"Q{(month_num-1)//3 + 1}"
                    for ec in equip_cols:
                        eq = ec['eq']
                        col_idx = ec['col_ton']
                        col_rend = ec['col_rend']
                        
                        raw_val = str(df_kpi.iloc[row_idx, col_idx]).replace(',', '')
                        val_total = pd.to_numeric(raw_val, errors='coerce')
                        
                        raw_rend = str(df_kpi.iloc[row_idx, col_rend]).replace(',', '')
                        val_rend = pd.to_numeric(raw_rend, errors='coerce')
                        
                        if pd.notna(val_total) and val_total > 0:
                            if eq in ["Pala 03", "Cargador Frontal"]:
                                data_rows.append({
                                    'Year': year, 'Month': month_num, 'Quarter': q,
                                    'Equipo': eq, 'Fase': 'Remanejo',
                                    'Ton': val_total, 'Rend': val_rend, 'Source': 'KPI-Palas'
                                })
                            else:
                                # Apply proportions for P04, P05, P06
                                # KEY CHANGE: Lookup by (Year, Month, Eq)
                                phases_data = phase_lookup.get((year, month_num, eq), [])
                                if not phases_data:
                                    # Fallback if not in Pala-Fase map for that month
                                    data_rows.append({
                                        'Year': year, 'Month': month_num, 'Quarter': q,
                                        'Equipo': eq, 'Fase': 'Remanejo', # Fallback phase (User Request)
                                        'Ton': val_total, 'Source': 'KPI-Palas'
                                    })
                                else:
                                    sum_pf_ton = sum([p['ton'] for p in phases_data])
                                    for p in phases_data:
                                        prop = p['ton'] / sum_pf_ton
                                        data_rows.append({
                                            'Year': year, 'Month': month_num, 'Quarter': q,
                                            'Equipo': eq, 'Fase': p['phase'],
                                            'Ton': val_total * prop, 'Rend': val_rend, 'Source': 'KPI-Palas'
                                        })
            
            else:
                # QUARTERLY PARSING (2028, 2029)
                row_quarter_map = {}
                
                for i in range(start_row, min(end_row + 1, len(df_kpi))):
                    val_1 = str(df_kpi.iloc[i, 1]).strip()
                    # print(f"DEBUG: Row {i} Col 1 Value: '{val_1}'")
                    
                    # ROBUST POSITIONAL ASSIGNMENT (Assuming Q1, Q2, Q3, Q4 order)
                    # Fallback to text check only if needed? No, force positional for stability.
                    offset = i - start_row
                    if offset < 4:
                        row_quarter_map[i] = offset + 1
                    else:
                        # Fallback for unexpected rows
                        if "1" in val_1: row_quarter_map[i] = 1
                        elif "2" in val_1: row_quarter_map[i] = 2
                        elif "3" in val_1: row_quarter_map[i] = 3
                        elif "4" in val_1: row_quarter_map[i] = 4
                
                for row_idx, quarter_num in row_quarter_map.items():
                    q = f"Q{quarter_num}"
                    
                    # Single Quarter Row (User Preference: Do not split)
                    # We use end-of-quarter month for sorting: 1->3, 2->6...
                    m_guide = quarter_num * 3
                    
                    for ec in equip_cols:
                        eq = ec['eq']
                        col_idx = ec['col_ton']
                        col_rend = ec['col_rend']

                        raw_val = str(df_kpi.iloc[row_idx, col_idx]).replace(',', '')
                        val_total = pd.to_numeric(raw_val, errors='coerce')
                        
                        if pd.notna(val_total) and val_total > 0:
                            # Direct Assignment (No Split)
                            if eq in ["Pala 03", "Cargador Frontal"]:
                                data_rows.append({
                                    'Year': year, 'Month': m_guide, 'Quarter': q,
                                    'Equipo': eq, 'Fase': 'Remanejo',
                                    'Ton': val_total, 'Rend': val_rend, 'Source': 'KPI-Palas'
                                })
                            else:
                                # For Phase: We take the proportions from the last month of quarter (proxy)
                                # or just average of quarter? Using last month is safest fallback provided in user code context
                                # KEY CHANGE: Lookup by (Year, Month, Eq)
                                phases_data = phase_lookup.get((year, m_guide, eq), [])
                                
                                # If missing, try previous months in quarter?
                                if not phases_data:
                                    for delta in [1, 2]:
                                        phases_data = phase_lookup.get((year, m_guide-delta, eq), [])
                                        if phases_data: break
                                        
                                if not phases_data:
                                    data_rows.append({
                                        'Year': year, 'Month': m_guide, 'Quarter': q,
                                        'Equipo': eq, 'Fase': 'Remanejo', # Fallback (User Request)
                                        'Ton': val_total, 'Source': 'KPI-Palas'
                                    })
                                else:
                                    sum_pf_ton = sum([p['ton'] for p in phases_data])
                                    for p in phases_data:
                                        prop = p['ton'] / sum_pf_ton
                                        data_rows.append({
                                            'Year': year, 'Month': m_guide, 'Quarter': q,
                                            'Equipo': eq, 'Fase': p['phase'],
                                            'Ton': val_total * prop, 'Rend': val_rend, 'Source': 'KPI-Palas'
                                        })

        # --- PART C: KPI-CAMIONES ---
        try:
            df_cam = pd.read_excel(file_path, sheet_name="KPI-Camiones", header=None)
            current_year = None # Reset
            
            for i in range(1, len(df_cam)):
                # Detect Year (in Col 0)
                val_y = df_cam.iloc[i, 0]
                if pd.notna(val_y):
                    try: 
                        y_maybe = int(val_y)
                        if y_maybe > 2000: current_year = y_maybe
                    except: pass
                
                label_m = str(df_cam.iloc[i, 1]).strip().upper()
                
                month_num = None
                quarter_label = None
                is_quarterly = False
                
                # Detect Month or Quarter
                # Detect Month or Quarter
                if label_m[:3] in months_dict:
                    month_num = months_dict[label_m[:3]]
                    quarter_label = f"Q{(month_num-1)//3 + 1}"
                elif "TRIMESTRE" in label_m or "Trimestre" in label_m:
                    q_num = 1
                    # Robust check
                    if "1" in label_m or "1ER" in label_m: q_num = 1
                    elif "2" in label_m or "2DO" in label_m: q_num = 2
                    elif "3" in label_m or "3ER" in label_m: q_num = 3
                    elif "4" in label_m or "4TO" in label_m: q_num = 4
                    elif "I" in label_m: q_num = 1 # Roman?
                    
                    quarter_label = f"Q{q_num}"
                    month_num = q_num * 3 # End of quarter for sort
                    is_quarterly = True
                
                if current_year and (month_num or quarter_label):
                    ton_val = pd.to_numeric(df_cam.iloc[i, 3], errors='coerce')
                    rend_val = pd.to_numeric(df_cam.iloc[i, 5], errors='coerce')
                    tc_val = pd.to_numeric(df_cam.iloc[i, 6], errors='coerce')
                    count_val = pd.to_numeric(df_cam.iloc[i, 8], errors='coerce') # Index 8 for count
                    
                    if pd.notna(ton_val):
                        # No Split for camiones either
                        data_rows.append({
                            'Year': current_year, 'Month': month_num, 'Quarter': quarter_label,
                            'Equipo': 'Camiones', 'Fase': 'Transporte',
                            'Ton': ton_val,
                            'Rend': rend_val,
                            'Count': count_val,
                            'Source': 'KPI-Camiones'
                        })
        except Exception as e_cam:
            print(f"Warning: Error loading KPI-Camiones: {e_cam}")

        print(f"DEBUG: Total rows extracted: {len(data_rows)}")
        return pd.DataFrame(data_rows)

    except Exception as e:
        print(f"Error V13: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()

def load_kpi_perfos_servicios(file_path):
    """
    Parses 'KPI-Perfos' and 'KPI-Servicios' based on verified structure:
    Rows 1-2: Headers.
    Columns:
       3-14: 2026 (Jan-Dec)
       16-27: 2027 (Jan-Dec)
       29-32: 2028 (Q1-Q4)
    Row Labels in Column 2.
    """
    print(f"--- LOADING PERFOS/SERVICIOS (CORRECT STRUCTURE) ---")
    data_points = []
    
    # Define Column Blocks (Audit Verified)
    # 2026: 3-14 (12 cols)
    # 2027: 16-27 (12 cols)
    # 2028: 29-32 (Q1-Q4) -> Col 29 is "1er Trimestre"
    # 2029: 34-37 (Q1-Q4) -> Assumed stride based on 2028 total at 33
    time_blocks = [
        {'year': 2026, 'cols': range(3, 15), 'type': 'monthly'},
        {'year': 2027, 'cols': range(16, 28), 'type': 'monthly'},
        {'year': 2028, 'cols': range(29, 33), 'type': 'quarterly'},
        {'year': 2029, 'cols': range(34, 38), 'type': 'quarterly'},
    ]
    
    sheets_config = {
        'KPI-Perfos': 'Perfos',
        'KPI-Servicios': 'Servicios'
    }
    
    # Enforce schema to avoid KeyError on empty results
    columns = ['Year', 'Month', 'Quarter', 'Category', 'Item', 'Metric', 'Value', 'Sheet']
    
    for sheet_name, category in sheets_config.items():
        try:
            df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)
            
            # FFill Category/Metric column (Col 1)
            # This handles "Mts Producción" -> "Total Flota" mapping
            df[1] = df[1].fillna(method='ffill')
            
            
            # Iterate over all rows to find Equipment/Metrics
            for i in range(len(df)):
                item_label = str(df.iloc[i, 2]).strip()
                metric_label = str(df.iloc[i, 1]).strip()
                
                if not item_label or item_label == 'nan': continue
                
                # Check if it's a relevant row (naive filter or accept all non-empty?)
                # We accept all, logic in Dashboard will filter by name
                
                for block in time_blocks:
                    year = block['year']
                    cols = block['cols']
                    
                    for idx, c in enumerate(cols):
                        if c >= df.shape[1]: continue
                        
                        val = pd.to_numeric(df.iloc[i, c], errors='coerce')
                        if pd.notna(val):
                            if block['type'] == 'quarterly':
                                # Single Row per Quarter (No Split)
                                q_num = idx + 1
                                q_label = f"Q{q_num}"
                                # Use month end of quarter as sort key if needed, or None
                                # 1->3, 2->6, 3->9, 4->12
                                m_sort = q_num * 3
                                
                                data_points.append({
                                    'Year': year,
                                    'Month': m_sort, # Helper for sorting
                                    'Quarter': q_label,
                                    'Category': category,
                                    'Item': item_label,
                                    'Metric': metric_label,
                                    'Value': val,
                                    'Sheet': sheet_name
                                })
                            else:
                                # Monthly
                                month = idx + 1
                                q_label = f"Q{(month-1)//3 + 1}"
                                
                                data_points.append({
                                    'Year': year,
                                    'Month': month,
                                    'Quarter': q_label,
                                    'Category': category,
                                    'Item': item_label,
                                    'Metric': metric_label, # e.g. "Mts Producción"
                                    'Value': val,
                                    'Sheet': sheet_name
                                })
                            
        except Exception as e:
            print(f"Error loading {sheet_name}: {e}")
            
    return pd.DataFrame(data_points, columns=columns)
