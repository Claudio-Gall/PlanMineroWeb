import pandas as pd
FILE_PATH = 'plan_budget_real.xlsx'

print("--- INSPECTING PALA-FASE END COLUMNS and ROW 13 ---")
try:
    df = pd.read_excel(FILE_PATH, sheet_name='Pala-Fase', header=None)
    
    total_cols = df.shape[1]
    last_20_start = max(0, total_cols - 20)
    
    print(f"Total Cols: {total_cols}")
    print("Row 0 (Years) Last 20:")
    print(df.iloc[0, last_20_start:].to_string())
    print("Row 1 (Months) Last 20:")
    print(df.iloc[1, last_20_start:].to_string())
    
    print("\nRow 13 Content:")
    print(df.iloc[13, 0:5].to_string())
    print(df.iloc[13, last_20_start:].to_string())

except Exception as e:
    print(f"Error: {e}")
