import fleet_v3
import pandas as pd
import sys

# Mock app.py helper
def generate_period_column(df_in):
    if df_in.empty: return df_in
    month_map = {1:'Jan', 2:'Feb', 3:'Mar', 4:'Apr', 5:'May', 6:'Jun',
                 7:'Jul', 8:'Aug', 9:'Sep', 10:'Oct', 11:'Nov', 12:'Dec'}
    def get_period_label(row):
        try:
            y = int(row['Year'])
            if y >= 2028:
                q = row.get('Quarter', '')
                return f"{q} {y}"
            else:
                m = int(row['Month'])
                m_name = month_map.get(m, str(m))
                return f"{m_name} {y}"
        except: return str(row.get('Year', ''))
    
    df_in['Periodo'] = df_in.apply(get_period_label, axis=1)
    return df_in

print("--- VERIFYING FINAL QUARTER LOGIC ---")
FILE_PATH = 'plan_budget_real.xlsx'

# 1. Fleet
try:
    df_fleet = fleet_v3.load_fleet_data_v3_hybrid(FILE_PATH)
    df_28 = df_fleet[df_fleet['Year'] == 2028]
    print(f"Fleet 2028 Rows: {len(df_28)}")
    
    unique_q = df_28['Quarter'].unique()
    print(f"Unique Quarters Fleet 2028: {unique_q}")
    
    # Filter for Camiones
    df_cam_28 = df_28[df_28['Equipo'] == 'Camiones']
    unique_q_cam = df_cam_28['Quarter'].unique()
    print(f"Unique Quarters Camiones 2028: {unique_q_cam}")
    if len(unique_q_cam) < 4:
        print("FAIL: Camiones missing quarters!")
    else:
        print("SUCCESS: Camiones has all quarters.")
        
    df_28 = generate_period_column(df_28)
    # print("Unique Periods Fleet:", df_28['Periodo'].unique())
        
except Exception as e:
    print(f"Fleet Error: {e}")
