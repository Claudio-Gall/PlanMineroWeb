import pandas as pd

FILE_PATH = 'plan_budget_real.xlsx'

print("--- AUDITING KPI-PALAS HEADERS (2028) ---")
try:
    df = pd.read_excel(FILE_PATH, sheet_name='KPI-Palas', header=None)
    # 2028 is supposedly Cols 27-30 or 29-32?
    # fleet_v3 says 2028 starts at Col 27?
    # Let's print rows 0-3 for cols 25-40 to be sure.
    print(df.iloc[27:31, 2:15].to_string())
except Exception as e:
    print(f"Error: {e}")
